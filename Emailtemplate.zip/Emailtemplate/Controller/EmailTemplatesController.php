<?php
/**
 * Static content controller.
 *
 * This file will render views from views/pages/
 *
 * CakePHP(tm) : Rapid Development Framework (http://cakephp.org)
 * Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright     Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 * @link          http://cakephp.org CakePHP(tm) Project
 * @package       app.Controller
 * @since         CakePHP(tm) v 0.2.9
 * @license       http://www.opensource.org/licenses/mit-license.php MIT License
 */

App::uses('AppController', 'Controller');

/**
 * Static content controller
 *
 * Override this controller by placing a copy in controllers directory of an application
 *
 * @package       app.Controller
 * @link http://book.cakephp.org/2.0/en/controllers/pages-controller.html
 */
class EmailTemplatesController  extends EmailtemplateAppController {

	     
    public $components = array( 'Search.Prg');
    
	public $presetVars = array(
        array('field' => 'subject', 'type' => 'value'),
        array('field' => 'category_id', 'type' => 'value'),
        array('field' => 'recordsPerPage', 'type' => 'value')
    );
	
	public function beforeFilter() {
        parent::beforeFilter();
		$this->set('model',$this->modelClass);
    }

/**
 * This controller does not use a model
 *
 * @var array
 */
	public $uses = array();
	
	function index(){
		
		$this->Prg->commonProcess();
        
        if (!empty($this->data) && isset($this->data[$this->modelClass]['recordsPerPage']) ) {
           $limit = $this->data[$this->modelClass]['recordsPerPage'];
            $this->Session->write($this->name . '.' . $this->action . '.recordsPerPage', $limit);
        }
            
        //set the limitvalue for records
        $limit = ($this->Session->read($this->name . '.' . $this->action . '.recordsPerPage' ) ) ? $this->Session->read( $this->name . '.' . $this->action . '.recordsPerPage'):Configure::read("Reading.record_per_page");
        
        $this->{$this->modelClass}->data[$this->modelClass]         =     $this->passedArgs;
        $parsedConditions = $this->{$this->modelClass}->parseCriteria($this->passedArgs);
       
		$this->paginate = array(
			'conditions' => $parsedConditions,
			'limit'      => $limit,
			'order'         =>  'id DESC'    
        );        
        $result    =    $this->paginate();
        $this->set('result', $result);
	} 
	
	
	
	public function add() {
		$category	=	$this->getActions('email_actions');
		$this->set('category',$category);
		if(!empty($this->data)){
			if($this->{$this->modelClass}->save($this->data)){
				$this->Session->setFlash('Template added successfully','success');
				$this->redirect(array('action' => 'index'));
			}
		}
	}
	
	public function edit($id='') {
		if($id == ''){
			$this->redirect(array('action' => 'index'));
		}
		if(!empty($this->data)){
			$this->{$this->modelClass}->id	=	$id;
			$data	=	array();
			$data['subject']	=	$this->data[$this->modelClass]['subject'];
			$data['body']	=	$this->data[$this->modelClass]['body'];
			if($this->{$this->modelClass}->save($data,false)){
				$this->Session->setFlash('Template updated successfully','success');
				$this->redirect(array('action' => 'index'));
			}
		}else{
			$category	=	$this->getActions('email_actions');
			$this->set('category',$category);
		
			$this->data	=	$this->{$this->modelClass}->findById($id);
		}
	}
	
	public function delete($id ='') {
		if($id == ''){
			$this->redirect(array('action' => 'index'));
		}
		$this->{$this->modelClass}->delete($id);
		$this->Session->setFlash('Template deleted successfully','success');
		$this->redirect(array('action' => 'index'));
		
	}	
	
	public function active($id ='',$status) {
		if($id == ''){
			$this->redirect(array('action' => 'index'));
		}
		$this->{$this->modelClass}->id	=	$id;
		$status	=	($status == 1) ? 0 : 1;
		$this->{$this->modelClass}->saveField('is_active',$status);
		$this->Session->setFlash('Status changed successfully','success');
		$this->redirect(array('action' => 'index'));
		
	}
	
	function getActions(){
		$this->loadModel('Action');
		return $this->Action->find('list',array('fields' => array('id','action')));
	}	
	
	function get_consatant($id=''){
		$this->loadModel('Action');
		$res	=	$this->Action->findById($id);
		$constant	=	explode(',',$res['Action']['constant']);
		$this->layout	=	false;
		$this->set('constant',$constant);
	}
	
	public function add_action() {
		if(!empty($this->data)){
			$savaData	=	array();
			$saveData['action']		=	$this->data[$this->modelClass]['action'];
			$saveData['constant']	=	implode(',',$this->data[$this->modelClass]['constant']);
			$this->loadModel('Action');
			$this->Action->save($saveData);
			
		}
	}
}
