-- phpMyAdmin SQL Dump
-- version 4.4.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jun 03, 2016 at 07:01 AM
-- Server version: 5.6.26
-- PHP Version: 5.6.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `clinical_trial`
--

-- --------------------------------------------------------

--
-- Table structure for table `actions`
--

CREATE TABLE IF NOT EXISTS `actions` (
  `id` bigint(20) NOT NULL,
  `action` varchar(255) NOT NULL,
  `constant` text NOT NULL,
  `created` datetime NOT NULL,
  `modifiied` datetime NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `actions`
--

INSERT INTO `actions` (`id`, `action`, `constant`, `created`, `modifiied`) VALUES
(1, 'registration_verification', 'EMAIL,VERIFICATION_LINK', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(2, 'forgot_password', 'USER_NAME,FORGOT_PASSWORD_LINK,LINK', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(4, 'thanks_for_registration', 'EMAIL', '2015-10-01 08:07:10', '0000-00-00 00:00:00'),
(5, 'reset_password', 'USER_NAME', '2015-11-17 11:38:59', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `email_templates`
--

CREATE TABLE IF NOT EXISTS `email_templates` (
  `id` bigint(20) NOT NULL,
  `action_id` bigint(20) NOT NULL,
  `action` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `body` longtext NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `email_templates`
--

INSERT INTO `email_templates` (`id`, `action_id`, `action`, `subject`, `body`, `created`, `modified`) VALUES
(1, 1, '', 'Verification email', '<p>Welcome {EMAIL}</p>\r\n\r\n<p>click on below link to verify your account</p>\r\n\r\n<p>{VERIFICATION_LINK}</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>Thanks &amp; </p>\r\n\r\n<p></p>\r\n', '2015-10-01 07:39:48', '2016-05-12 14:06:24'),
(3, 2, '', 'Forgot password email', '<h1><strong>Hello, </strong>{USER_NAME}<br />\r\n<br />\r\nPlease follow the link to reset your password.</h1>\r\n\r\n<p>{FORGOT_PASSWORD_LINK}<br />\r\n<br />\r\nOR<br />\r\n<br />\r\nCopy the URL below&nbsp;into your browser.<br />\r\n{LINK}<br />\r\n<br />\r\n<br />\r\n&nbsp;<br />\r\n<br />\r\</p>\r\n', '2015-10-01 07:49:31', '2016-05-12 14:06:28'),
(4, 4, '', 'Thanks for registration', '<p>Hello {EMAIL}</p>\r\n\r\n<p>Thanks for register.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>Thanks &amp; </p>\r\n\r\n<p></p>\r\n\r\n<p>&nbsp;</p>\r\n', '2015-10-01 08:08:05', '2016-05-12 14:06:34'),
(5, 5, '', 'Reset password', '<h3><strong>Hello,</strong>{USER_NAME}</h3>\r\n\r\n<p>Your password has been changed&nbsp;successfully.<br />\r\n<br />\r\&nbsp;<br />\r\n<br />\r\n<br />\r\</p>\r\n', '2015-11-17 11:39:35', '2016-05-12 14:06:38');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `actions`
--
ALTER TABLE `actions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `email_templates`
--
ALTER TABLE `email_templates`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `actions`
--
ALTER TABLE `actions`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `email_templates`
--
ALTER TABLE `email_templates`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=16;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
